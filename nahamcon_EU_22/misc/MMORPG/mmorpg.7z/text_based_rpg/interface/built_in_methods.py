import time

input_ = input

def _print(x=""):
	print(x)

print_ = _print

def _sleep(x):
	return
sleep = _sleep
