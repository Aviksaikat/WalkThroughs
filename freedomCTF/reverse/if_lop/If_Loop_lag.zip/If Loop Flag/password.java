public class password {
   public static void main(String[] args) {
      int i = 0;
      int j = 0;
      String sOne = "";
      String sTwo = "";
      String sThree = "";
      if (i == 1) {
         sOne = "h";
         i++;
         i++;
      }
       
      else if (i == 1) {
         sOne = "n";
         i++;
         i++;
         i++;         
      }
       
      else if (i == 1) {
         sOne = "a";
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "c";
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "q";
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "i";
         i++;
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "z";
         i++;         
      }
      
      else if (i == 1) {
         sOne = "u";
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "e";
         i++;
         i++;
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "s";
         i++;
         i++;
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "l";
         i++;
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "g";
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "w";
         i++;
         i++;
         i++;
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "y";
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "d";
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "m";
         i++;
         i++;
         i++;
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "p";
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "r";
         i++;         
      }
      
      else if (i == 1) {
         sOne = "x";
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "j";
         i++;
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "b";
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "v";
         i++;         
      }
      
      else if (i == 1) {
         sOne = "k";
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;         
      }
      
      else if (i == i) {
         sOne = "f";
         i++;
         i++;
         i++;
         i++;         
      }
      
      else if (i == 1) {
         sOne = "o";
         i++;
         i++;
         i++;
         i++;         
      }
      
      else {
         sOne = "t";
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;
         i++;         
      }
      
      //"lag"
      //"{"
      
      if (j == 1) {
         sThree = "h";
          
         j++;
         j++;
      }
      j++;
      j++;
      
      if (j == 5) {
         sThree = "_";
          
         j++;
         j--;
         j++;
      }
      j++;
      j++;
      j++;
      
      if (j == 1) {
         sThree = "n";
          
         j++;
         j--;
         j++;
      }
       
      else if (j == 3) {
         sThree = "a";
          
         j++;
         j++;
         j--;
         j++;
         j--;
         j++;
         j++;
      }
      
      else if (j == 5) {
         sThree = "l";
          
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      j--;
      j--;
      
      if (j == 8) {
         sThree = "i";
          
         j++;
         j++;
      }
      
      else if (j == 1) {
         sThree = "f";
          
         j++;
         j--;
         j++;
         j++;
      }
      
      else if (j == 10) {
         sThree = "o";
          
         j++;
         j++;
         j--;
         j++;
      }
      
      j--;
      j--;
      j--;
      j--;
      j--;
      j++;
      j--;
      j--;
      j--;
      j--;
      j--;
      j--;
      j++;
      j++;
      j--;
      
      if (j == 8) {
         sThree = "_";
          
         j++;
         j++;
         j++;
      }
       
      else if (j == 3) {
         sThree = "t";
          
         j--;
         j--;
         j--;
      }
      j--;
      j++;
      j++;
      j--;
      
      if (j == 5) {
         sThree = "a";
          
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 0) {
         sThree = "s";
          
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 6) {
         sThree = "i";
          
         j++;
         j++;
         j++;
      }
      
      else if (j == 8) {
         sThree = "z";
          
         j++;
         j++;
      }
      
      else if (j == -3) {
         sThree = "u";
          
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 3) {
         sThree = "e";
          
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 1) {
         sThree = "s";
          
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 8) {
         sThree = "l";
          
         j =  (int)(Math.PI/Math.PI);
         j++;
         j++;
         j++;
      }
      j++;
      j++;
      j--;
      j--;
      j++;
      j--;
      
      if (j == 12) {
         sThree = "_";
          
         j++;
         j++;
         j++;
         j++;
         j = 0;
      }
      
      
      else if (j == 18) {
         sThree = "m";
          
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 3) {
         sThree = "_";
          
         j++;
         j++;
         j++;
      }
      //j
      
      if (j == 7) {
         sThree = "h";
          
         j++;
         j++;
      }
       
      else if (j == 12) {
         sThree = "n";
          
         j++;
         j++;
         j++;
      }
      j++;
      j++;
      j++;
      
      if (j == 5) {
         sThree = "k";
          
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      j++;
      j++;
       
      if (j == 5) {
         sThree = "f";
          
         j++;
         j++;
         j++;
      }
      
      else if (j == 11) {
         sThree = "z";
          
         j++;
         j++;
      }
      j++;
      j++;
      j++;
      j++;
      
      if (j == 4) {
         sThree = "u";
          
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 17) {
         sThree = "e";
          
         j++;
         j++;
         j++;
         j++;
      }
      
      if (j == 12) {
         sThree = "_";
          
         j++;
         j++;
         j++;
         j++;
      }
       
      else if (j == 7) {
         sThree = "a";
          
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 2) {
         sThree = "g";
          
         j++;
         j++;
      }
      j--;
      j--;
      
      if (j == 0) {
         sThree = "w";
          
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      j++;
      j--;
      j--;
      j--;
      
      if (j == 11) {
         sThree = "y";
          
         j++;
         j++;
      
      }
      
      else if (j == 7) {
         sThree = "i";
          
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      j--;
      
      if (j == 0) {
         sThree = "z";
          
         j++;
         j++;
      }
      
      else if (j == 7) {
         sThree = "_";
          
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      j++;
      j++;
      j++;
      
      if (j == 1) {
         sThree = "u";
          
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 5) {
         sThree = "_";
          
         j++;
         j++;
         j++;
      }
      
      else if (j == 14) {
         sThree = "i";
          
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 7) {
         sThree = "s";
          
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 11) {
         sThree = "m";
          
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 3) {
         sThree = "h";
          
         j++;
         j++;
      }
      
      if (j == j) {
         j = 0;
         j++;
         j++;
      }
      
      else if (j == 6) {
         sThree = "n";
          
         j++;
         j++;
         j++;
      }
      j++;
      
      if (j == 5) {
         sThree = "k";
          
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 3) {
         sThree = "f";
          
      }
      
      else if (j == 2) {
         sThree = "_";
          
         j++;
         j++;
         j++;
      }
      
      if (j == 8) {
         sThree = "o";
          
         j++;
         j++;
         j++;
         j++;
      }
       
      else if (j == 2) {
         sThree = "a";
          
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 0) {
         sThree = "p";
          
         j++;
         j++;
      }
      
      else if (j == 3) {
         sThree = "s";
          
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 8) {
         sThree = "l";
          
         j++;
         j++;
         j++;
      }
      
      else if (j == 0) {
         sThree = "g";
          
         j++;
         j++;
      }
      
      else if (j == 2) {
         sThree = "r";
          
         j++;
      }
      
      else if (j == 5) {
         sThree = "_";
          
         j++;
         j++;
         j++;
      }
      
      else if (j == 1) {
         sThree = "x";
          
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 5) {
         sThree = "j";
          
         j++;
         j++;
         j++;
      }
      
      else if (j == 13) {
         sThree = "b";
          
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 19) {
         sThree = "v";
          
         j++;
         j++;
      }
      
      else if (j == 16) {
         sThree = "k";
          
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 3) {
         sThree = "f";
          
         j++;
         j++;
         j++;
         j++;
      }
      
      else if (j == 6) {
         sThree = "o";
          
         j++;
         j++;
         j++;
         j++;
      }
      
      else {
         sThree = "s";
          
         j++;
      }
      //"}"
   }
}